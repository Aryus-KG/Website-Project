const btn = document.getElementById("btn");
const text = document.getElementById("quoteText");
const quote = [
  "Hidup Blondee",
  "Wiwok De Tok, Not Onli Tok Detok",
  "INGAT, Darah Keturunan Vibe Coder....",
  "PHP Kunoo",
  "Aku? Pakai Python? Cuihh Ketularan Lemott"
  ];
  
  console.log(quote[1])
  
function randomQuote (){
  const randomIndex = Math.floor(Math.random * quote.length);
  
  console.log(randomIndex)
  
  text.innerHTML = quote[randomIndex];
  console.log(quote[randomIndex]);
}

btn.addEventListener("click", () => randomQuote())